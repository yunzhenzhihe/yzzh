<?php
namespace Home\Model;
use Think\MOdel;
class IndexModel extends Model{

}