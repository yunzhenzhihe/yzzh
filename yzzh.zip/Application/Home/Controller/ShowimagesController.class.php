<?php
namespace Home\Controller;
use Think\Controller;

//图片管理模块
class ShowimagesController extends Controller {

	public function index()
    {
        $M = M('image');
        $count = $M->count();
        $page = new \Think\Page($count,24);
        $show = $page->show();
        $res = $M->field('image_name,image_url,id')->limit($page->firstRow.','.$page->listRows)->select();
        $this->assign('res',$res);
        $this->assign('page',$show);
        $this->display();
    }
    public function webup()
    {
        $config = array(
            'mimes' => array(), //允许上传的文件MiMe类型
            'maxSize' => 0, //上传的文件大小限制 (0-不做限制)
            'exts' => array('jpg', 'gif', 'png', 'jpeg'), //允许上传的文件后缀
            'autoSub' => false, //自动子目录保存文件
            'rootPath' => './', //保存根路径
            'savePath' => 'Public/Uploads/',//保存路径

        );
        $upload = new \Think\Upload($config);// 实例化上传类


        $info = $upload->upload();

        if (!$info) {

            $this->error($upload->getError());// 上传错误提示错误信息

        } else {// 上传成功
            foreach ($info as $file) {
                $data['image_name'] = $file['savename'];
                $data['image_url'] = $file['savepath'];
                $images = D('Image');
                $images->create($data,1);
                $images->add();
            }
        }
    }
    public function delete(){
	    $M = M('image');
	    $map['id'] = I('post.id');
	    if($M->where($map)->delete()){
	        $this->success('删除成功！');
        }else{
	        $this->error('删除失败！');
        }
    }

    public function group(){
        $M = M('image');
        $count = $M->count();
        $page = new \Think\Page($count,24);
        $show = $page->show();
        $list = $M->field('image_name,image_url,id')->limit($page->firstRow.','.$page->listRows)->select();
        $info = M('yzgoodsinfo');
        $map['check'] = array('in','3,4');
        $res = $info->field('attr,value')->where($map)->select();
        foreach ($res as $k=>$v){
            $res[$k]['value'] = explode(',',$v['value']);
        }
//        var_dump($res);
        $this->assign('res',$list);
        $this->assign('page',$show);
        $this->display('Showimages/images_group');
    }
}