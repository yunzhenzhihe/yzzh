<?php
// 首页
namespace Home\Controller;
use Think\Controller;

class IndexController extends PublicController {
	
   function  index_menu(){   //首页   
 
		
		$this->display();

	}

}
